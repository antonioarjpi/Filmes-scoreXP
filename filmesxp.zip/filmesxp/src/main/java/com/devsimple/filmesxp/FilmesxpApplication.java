package com.devsimple.filmesxp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmesxpApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmesxpApplication.class, args);
	}

}
